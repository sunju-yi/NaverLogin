package com.test.tst;

import lombok.Data;

@Data
public class DBConnectBO {
	private String client_name;
	private String client_email;
	private String client_phone;
	private String client_nickname;
}
