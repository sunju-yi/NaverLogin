package com.login.domain;

import lombok.Data;

@Data
public class lombokTest {

}

/*
���� URL
http://localhost:8080/tst/login

���̹��α��� callback URL
http://localhost:8080/tst/callback


clientID
befRtq8NaFqGhfDt7Unv

clientSecret
UUSPa9j1A2
*/