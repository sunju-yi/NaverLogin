package com.test.tst;

import lombok.Data;

@Data
public class RegisterVO {
	private String c_name;
	private String nickname;
	private String e_mail;
	private String phone_no;
	
}
