package com.test.mapper;

import java.util.List;

import com.test.tst.ClientLogVO;

public interface ClientMapper {
	public List<ClientLogVO> getList();
	public void insert(ClientLogVO c_VO);
	public void insertSelectKey(ClientLogVO c_VO);
	public ClientLogVO read(long l);
	public boolean delete(long l);
	public int update(ClientLogVO board);
}
